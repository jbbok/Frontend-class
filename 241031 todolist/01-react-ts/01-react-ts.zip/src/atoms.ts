import { atom } from "recoil";

interface ToDo {
  id: number;
  text: string;
  category: "TODO" | "DOING" | "DONE";
}

export const toDoState = atom<ToDo[]>({
  key: "toDo",
  default: [],
});
