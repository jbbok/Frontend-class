import React from "react";
import 

const ToDo = ({ text }) => {
  return <li>{text}</li>;
};

export default ToDo;
