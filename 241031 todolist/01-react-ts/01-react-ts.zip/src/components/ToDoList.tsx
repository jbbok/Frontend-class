import styled from "styled-components";
import { useRecoilValue } from "recoil";
import CreateToDo from "./CreateToDo";
import { toDoState } from "../atoms";

const Container = styled.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  gap: 10px;
  margin-top: 50px;
`;

const Title = styled.h1`
  margin-bottom: 10px;
  padding-bottom: 10px;
  border-bottom: 1px solid lightgrey;
`;

interface Form {
  toDo: string;
}

const ToDoList = () => {
  const toDos = useRecoilValue(toDoState);
  console.log(toDos);

  return (
    <Container>
      <Title>ToDo List</Title>
      <CreateToDo />
      <ul>
        {toDos.map((toDo) => (
          <li key={toDo.id}>{toDo.text}</li>
        ))}
      </ul>
    </Container>
  );
};

export default ToDoList;
